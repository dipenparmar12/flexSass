// Hello World 
console.log("NestScript JS");