// Hello World 
console.log("OkHello World"+ "File Two NEw Gulp Syntax as per Version 4");

// Hello There
console.log("HeLlo There"+"File Two Heloer");
// TestCommnet///
console.log("DoneWOKINGOKAy");

